php -v
sudo update-alternatives --set php /usr/bin/php7.0
sudo a2dismod php7.2
sudo a2enmod php7.0
sudo systemctl restart apache2
php -v
php -i | grep 'php.ini'
