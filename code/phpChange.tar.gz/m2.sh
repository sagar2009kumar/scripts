baseDir='/var/www/html/staysafe';

php "$baseDir/bin/magento cache:flush"

sudo rm -rf "$baseDir/var/cache"
sudo rm -rf "$baseDir/var/page_cache"
sudo rm -rf "$baseDir/generated"

# for cleaning the chache
# php /var/www/html/magento2/bin/magento cache:clean

sudo chmod -R 777 "$baseDir/var/page_cache"
sudo chmod -R 777 "$baseDir/var/generated"
sudo chmod -R 777 "$baseDir/var/generated/code"
sudo chmod -R 777 "$baseDir/var/cache"
sudo chmod -R 777 "$baseDir/var"
sudo chmod -R 777 "$baseDir/pub"
sudo chmod -R 777 "$baseDir/vendor"

# getting the list of all the modules
# php /var/www/html/magento2/bin/magento module:status

# for listing of the magento command list
# php bin/magento list

# for upgrading the database of the configuration
# php /var/www/html/magento2/bin/magento setup:upgrade

# for setting the mode of the magento to developer mode
# sudo /var/www/html/magento2/bin/magento deploy:mode:set developer

# for compiling of the file
# sudo bin/magento setup:di:compile
