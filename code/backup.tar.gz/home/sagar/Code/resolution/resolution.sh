
sudo su

sudo xrandr --newmode "1366x768_60.00"   85.25  1368 1440 1576 1784  768 771 781 798 -hsync +vsync

sudo xrandr --addmode DP-1 "1366x768_60.00"
