<?php

class Yuginfotech_BottleDeposit_Block_Sales_Invoice extends Mage_Sales_Block_Order_Invoice_Totals
{
    protected $_code = 'bottledeposit';

    protected function _initTotals()
    {
        parent::_initTotals();
        $invoice = $this->getInvoice();
        $amt = $invoice->getBottleDeposit();
        $baseAmt = $this->getSource()->getBaseFeeAmount();
        if ($amt > 0) {
            $this->addTotal(new Varien_Object(array(
                'code' => $this->_code,
                'value' => $amt,
                'base_value' => $baseAmt,
                'label' => Mage::helper('bottledeposit')->__('Bottle Deposit'),
            )), array('shipping', 'tax'));
        }
        return $this;
    }
} 