<?php

class Yuginfotech_BottleDeposit_Block_Adminhtml_Sales_Order extends Mage_Adminhtml_Block_Sales_Order_Totals
{
    protected $_code = 'bottledeposit';

    protected function _initTotals()
    {
        parent::_initTotals();
        $orderobj = $this->getOrder();
        $amt = $orderobj->getBottleDeposit();
        $baseAmt = $this->getSource()->getBaseFeeAmount();
        if ($amt > 0) {
            $this->addTotal(new Varien_Object(array(
                'code' => $this->_code,
                'value' => $amt,
                'base_value' => $baseAmt,
                'label' => Mage::helper('bottledeposit')->__('Bottle Deposit'),
            )), 'bottledeposit');
        }
        return $this;
    }
} 