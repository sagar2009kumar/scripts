<?php
$this->startSetup();
$installer = new Mage_Sales_Model_Resource_Setup('core_setup');

$entities = array(
    'invoice',
    'order'
);
$options = array(
    'type'     => Varien_Db_Ddl_Table::TYPE_DECIMAL,
    'visible'  => true,
    'required' => false
);
foreach ($entities as $entity) {
    $installer->addAttribute($entity, 'bottle_deposit', $options);
}

$this->run("
ALTER TABLE  `".$this->getTable('sales/quote_address')."` ADD  `bottle_deposit` DECIMAL( 10, 2 ) NOT NULL;
");

$this->endSetup();