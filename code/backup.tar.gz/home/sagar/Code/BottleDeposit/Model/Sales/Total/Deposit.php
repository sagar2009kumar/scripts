<?php

class Yuginfotech_BottleDeposit_Model_Sales_Total_Deposit extends Mage_Sales_Model_Quote_Address_Total_Abstract
{
    protected $_code = 'bottledeposit';

    public function collect(Mage_Sales_Model_Quote_Address $address)
    {
        parent::collect($address);

        $this->_setAmount(0);
        $this->_setBaseAmount(0);

        $items = $this->_getAddressItems($address);
        if (!count($items)) {
            return $this; //this makes only address type shipping to come through
        }

        /** @var Mage_Sales_Model_Quote $quote */
        $quote = $address->getQuote();

        if ($address->getAddressType() == 'shipping') {
            $quoteItems = $quote->getAllVisibleItems();
            $bottleDeposit = 0;
            /** @var Yuginfotech_BottleDeposit_Helper_Data $helper */
            $helper = Mage::helper('bottledeposit');
            /** @var Mage_Sales_Model_Quote_Item $quoteItem */
            foreach ($quoteItems as $quoteItem) {
                if ($quoteItem->getProductType() == 'giftcards') {
                    continue;
                } elseif ($quoteItem->getProductType() == 'bundle') {
                    if ($quoteItem->getHasChildren()) {
                        foreach ($quoteItem->getChildren() as $child) {
                            $product = $child->getProduct();
                            $bottle_size = $product->getData('bottle_size');
                            if (!empty($bottle_size)) {
                                $bottle_size = (int)str_replace('ml', '', $bottle_size);
                            }
                            $depoAmtPerBottle = $helper->getDepositRate($bottle_size);
                            $totalQty = $child->getTotalQty();
                            $itemDepoAmt = $depoAmtPerBottle * $totalQty;
                            $bottleDeposit = $bottleDeposit + $itemDepoAmt;
                        }
                    }
                } else {
                    $product = $quoteItem->getProduct();
                    $hasProductDeposit = false;
                    if ($product->hasData('has_bottle_deposit')) {
                        $hasProductDeposit = $product->getData('has_bottle_deposit');
                    } else {
                        $product = Mage::getModel('catalog/product')->load($product->getId());
                        $hasProductDeposit = $product->getData('has_bottle_deposit');
                    }
                    if ($hasProductDeposit) {
                        if ($product->getData('visibility') != '' && $product->getData('visibility') != Mage_Catalog_Model_Product_Visibility::VISIBILITY_NOT_VISIBLE) {
                            $bottle_size = $product->getData('bottle_size');
                            if (!empty($bottle_size)) {
                                $bottle_size = (int)str_replace('ml', '', $bottle_size);
                            }
                            $depoAmtPerBottle = $helper->getDepositRate($bottle_size);
                            $totalQty = $quoteItem->getTotalQty();
                            if ((int)$quoteItem->getIsCase()) {
                                $bottlePerCase = (int)$quoteItem->getBottlePerCase();
                                $totalQty = $totalQty * $bottlePerCase;
                            }
                            $itemDepoAmt = $depoAmtPerBottle * $totalQty;
                            $bottleDeposit = $bottleDeposit + $itemDepoAmt;
                        }
                    }
                }
            }

            $address->setBottleDeposit($bottleDeposit);

            $quote->setBottleDeposit($bottleDeposit);

            $address->setGrandTotal($address->getGrandTotal() + $address->getBottleDeposit());
            $address->setBaseGrandTotal($address->getBaseGrandTotal() + $address->getBottleDeposit());
        }
    }

    public function fetch(Mage_Sales_Model_Quote_Address $address)
    {
        $amt = $address->getBottleDeposit();
        $address->addTotal(array(
            'code' => $this->getCode(),
            'title' => Mage::helper('bottledeposit')->__('Bottle Deposit'),
            'value' => $amt
        ));
        return $this;
    }
} 