<?php

class Yuginfotech_BottleDeposit_Model_Sales_Total_Pdf extends Mage_Sales_Model_Order_Pdf_Total_Default
{

    public function getTotalsForDisplay()
    {
        $fontSize = $this->getFontSize() ? $this->getFontSize() : 7;


            $totals = array(
                'amount'    => $this->getOrder()->formatPriceTxt($this->getAmount()),
                'label'     => Mage::helper('bottledeposit')->__($this->getTitle()) . ':',
                'font_size' => $fontSize
            );
        return array($totals);
    }
}