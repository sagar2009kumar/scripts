<?php

class Yuginfotech_BottleDeposit_Model_Sales_Order_Total_Deposit extends Mage_Sales_Model_Order_Invoice_Total_Abstract
{

    public function collect(Mage_Sales_Model_Order_Invoice $invoice)
    {
        $order = $invoice->getOrder();
        $amount = $order->getBottleDeposit();
        if ($amount) {
            //$invoice->setBottleDeposit($amount);
            $invoice->setGrandTotal($invoice->getGrandTotal() + $amount);
            $invoice->setBaseGrandTotal($invoice->getBaseGrandTotal() + $amount);
        }

        return $this;
    }

}