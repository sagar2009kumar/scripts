<?php

class Yuginfotech_BottleDeposit_Model_Observer {
    public function setBottleDepositToInvoice($observer){
        $invoice = $observer->getInvoice();
        $order = $observer->getOrder();
        $invoice->setBottleDeposit($order->getBottleDeposit());
    }

    public function salesOrderToInvoice($observer){
        $target = $observer->getTarget();
        $source = $observer->getSource();
        $target->setBottleDeposit($source->getBottleDeposit());
    }

    public function addBottleDepositToPayPalCart($observer){
        /** @var Mage_Paypal_Model_Cart $paypal_cart */
        $paypal_cart = $observer->getPaypalCart();
        $salesEntity = $paypal_cart->getSalesEntity();
        if($salesEntity instanceof Mage_Sales_Model_Order){
            $observer->getPaypalCart()->addItem(Mage::helper('bottledeposit')->__('Bottle Deposit'),1,$salesEntity->getBottleDeposit());
        } elseif($salesEntity instanceof Mage_Sales_Model_Quote){
            $observer->getPaypalCart()->addItem(Mage::helper('bottledeposit')->__('Bottle Deposit'),1,$salesEntity->getBottleDeposit());
        }
        return $this;
        //Mage::log($paypal_cart->getTotals(true));
    }
}