<?php

class Yuginfotech_BottleDeposit_Helper_Data extends Mage_Core_Helper_Abstract
{

    public function getBottleDepositAmt($product)
    {
        $currentStore = Mage::app()->getStore()->getCode();
        $bottle_size = $product->getData('bottle_size');
        $depoAmt = 0.2;
        if ($currentStore == 'alberta') {
            $depoAmt = 0.1;
        } else {

        }
        return $depoAmt;
    }

    public function getDepositRate($size)
    {
        $currentStore = Mage::app()->getStore()->getCode();
        if ($currentStore == 'alberta') {
            return $this->getDepositRateAlberta($size);
        }
        return $this->getDepositRateOthers($size);
    }

    public function getDepositRateAlberta($size)
    {
        $depoAmt = 0.1;
        $bottleRate = (float)Mage::getStoreConfig('bottledeposit/deposit_rate/alberta_all');
        $bottleRate = round($bottleRate,2);
        if($bottleRate > 0){
            $depoAmt = $bottleRate;
        }
        return $depoAmt;
    }

    public function getDepositRateOthers($size = '')
    {
        $depoAmt = 0.2;
        $bottleRate = (float)Mage::getStoreConfig('bottledeposit/deposit_rate/ontario_gt_500');
        $bottleRate = round($bottleRate,2);
        if($bottleRate > 0){
            $depoAmt = $bottleRate;
        }
        if (!empty($size)) {
            if ($size < 500) {
                $depoAmt = 0.1;
                $bottleRate = (float)Mage::getStoreConfig('bottledeposit/deposit_rate/ontario_lt_500');
                $bottleRate = round($bottleRate,2);
                if($bottleRate > 0){
                    $depoAmt = $bottleRate;
                }
            }
        }
        return $depoAmt;
    }
} 