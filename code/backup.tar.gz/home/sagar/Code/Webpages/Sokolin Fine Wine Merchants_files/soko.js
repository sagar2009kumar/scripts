// JavaScript Document

/***************Setup jQuery NoConflict with Prototype****************************/
jQuery.noConflict(); 
  
/*******Freatured Products Areas******/
jQuery(document).ready(function(){
	jQuery('#tabs div').hide();
	jQuery('#tabs div:first').show();
	var showing = "#tabs div:first" + " div";
	jQuery(showing).show();
	jQuery('#tabs ul li:first').addClass('active');
	jQuery("[id^=loading]").css({"display":"none"});
	jQuery('#tabs ul li .navtabs').click(function(){
		jQuery('#tabs ul li').removeClass('active');
		jQuery(this).parent().addClass('active');
		var currentTab = jQuery(this).attr('href');
		jQuery('#tabs div').hide();
		jQuery(currentTab).show();
		var showing = currentTab + " div";
		jQuery(showing).show();
		
		return false;
	});
	/**************Add Varien Input Field Validation***************/
	var sellwineform = new VarienForm('sellwineform');
	
	//jQuery('#demo').Horinaja({capture:'demo',delai:0.3,duree:4,pagination:true});

	
	/**************Toggle for Gift Service Request Form***************/
	jQuery(".giftrequest").hide();
	  //toggle the componenet with class
	jQuery(".opengiftrequest").click(function()
	  {
		jQuery(".giftrequest").slideToggle(500);
	  });

	jQuery("#slider").easySlider({
		auto: true,
		continuous: true
	});


  	jQuery('#submit_btn').click(function(){
		jQuery('#loading'+(jQuery(this).attr("value"))).html('<img src="/media/loader/ajax-loader.gif" />');
	});
	
	jQuery(".top-bar-search").hover(function(){
    	jQuery(".search-link").css("text-shadow", "none");
    }, function(){
    	jQuery(".search-link").css("text-shadow", "0 0 0.1em #ffffff, 0 0 0.1em #ffffff, 0 0 0.1em #ffffff");
	});
	
	
});


function activatemobilenav() {

	
	var n = jQuery(".nav-container").css("display");
	if(n == 'none'){
		jQuery('.nav-container').css({ "display": "block" });
	} else {
		jQuery('.nav-container').css({ "display": "none" });
	}

}



function sokoaddtocart(product_id, format, sku2, inventory){
	//jQuery('.loading'+product_id).html('<img src="/media/loader/ajax-loader.gif" />');
	
	if (format == '9L') {
		window.alert("Large formats over "+format+" cannot be purchased online. To order this wine, please call 800.946.3947 and one of our wine specialists will work with you to arrange shipping");
		return;
	}
	if (format == '12L') {
		window.alert("Large formats over "+format+" cannot be purchased online. To order this wine, please call 800.946.3947 and one of our wine specialists will work with you to arrange shipping");
		return;
	}
	if (format == '15L') {
		window.alert("Large formats over "+format+" cannot be purchased online. To order this wine, please call 800.946.3947 and one of our wine specialists will work with you to arrange shipping");
		return;
	}
	if (format == '18L') {
		window.alert("Large formats over "+format+" cannot be purchased online. To order this wine, please call 800.946.3947 and one of our wine specialists will work with you to arrange shipping");
		return;
	}
	var n = sku2.indexOf("OWC");
	var m = sku2.indexOf("XX2");
	//window.alert("Not Firing: "+m);
	if (n != '-1') {	
		var owc = sku2.split("-");
		var owc2 = owc[0].split(".");
		var requiredowcqty=owc2[1].replace("OWC","");
		
		var bottleqty = jQuery("#bottleqty"+product_id).val();
		if (bottleqty == ''){
		bottleqty = 1;
		};
		bottleqty = bottleqty * requiredowcqty
		//window.alert("/checkout/cart/add/product/"+product_id+"/qty/"+bottleqty);
		//return;
		setTimeout(function(){
				window.location = "/checkout/cart/add/product/"+product_id+"/qty/"+bottleqty;
			},800);
		
	} else if (m != '-1') {		
		var bottleqty = jQuery("#bottleqty"+product_id).val();
		if (bottleqty == ''){
		bottleqty = 1;
		};
		bottleqty = bottleqty * 12
		//window.alert("/checkout/cart/add/product/"+product_id+"/qty/"+bottleqty);
		//return;
		setTimeout(function(){
				window.location = "/checkout/cart/add/product/"+product_id+"/qty/"+bottleqty;
			},800);
	
	} else {
		jQuery('#loading'+product_id).css({"display":"block"});
		// Setup Variables
		var bottleqty = jQuery("#bottleqty"+product_id).val();
		var caseqty = jQuery("#caseqty"+product_id).val();
		var casesize = 12;
		var result;
		
		if(typeof caseqty === 'undefined'){
		   caseqty = 0;
		 };
		// Set Case Size dependent on bottle size
		if (format == '375 ml') {
			casesize =  24;
		}
		else if (format == "1.5L"){
			caseqty = '';
		};
		
		//Calculate Total # of Bottles	
		if (bottleqty != '' & caseqty != '') {
			caseqty = caseqty * casesize;
			
			bottleqty = parseFloat(bottleqty) + parseFloat(caseqty);
			//window.alert("1BOOM BottleQty: "+caseqty);
		  }
		else if (caseqty != ''){
			caseqty = caseqty * casesize;
			bottleqty = caseqty;
			//window.alert("2BOOM BottleQty: "+bottleqty);
		}
		else if (bottleqty == ''){
			bottleqty = 1;
			//window.alert("3BOOM BottleQty: "+bottleqty);
		};
		
		setTimeout(function(){
				window.location = "/checkout/cart/add/product/"+product_id+"/qty/"+bottleqty;
			},800)	
	}
};

function sokoupsell(product_id, format, sku2, inventory){
	 jQuery('#loading'+product_id).html('<img src="/media/loader/ajax-loader.gif" />');	
	 jQuery('[id^=realtimenotice]').fadeOut('slow', function() {
		// Animation complete
		jQuery('[id^=realtimenotice]').text('');
	});
	
	// Setup Variables
	var bottleqty = jQuery("#bottleqtyup"+product_id).val();
	var result;
	
	//Calculate Total # of Bottles	
	if (bottleqty == ''){
		bottleqty = 1;
	};
	
	setTimeout(function(){
		window.location = "/checkout/cart/add/product/"+product_id+"/qty/"+bottleqty;
	},800)	
	
};


function sokoaddtocartlastcall(product_id, format){
	
	var bottleqty = jQuery("#bottleqty"+product_id).val();
	
	if (bottleqty != '') {
	  	window.location = "/checkout/cart/add/product/"+product_id+"/qty/"+bottleqty;
	  }
	else 
	  {
	  	window.location = "/checkout/cart/add/product/"+product_id+"/qty/1";
	  }
};

/*!
* jQuery Cookie Plugin v1.3.1
* https://github.com/carhartl/jquery-cookie
*
* Copyright 2013 Klaus Hartl
* Released under the MIT license
*/
(function (factory) {
if (typeof define === 'function' && define.amd) {
// AMD. Register as anonymous module.
define(['jquery'], factory);
} else {
// Browser globals.
factory(jQuery);
}
}(function ($) {

var pluses = /\+/g;

function raw(s) {
return s;
}

function decoded(s) {
return decodeURIComponent(s.replace(pluses, ' '));
}

function converted(s) {
if (s.indexOf('"') === 0) {
// This is a quoted cookie as according to RFC2068, unescape
s = s.slice(1, -1).replace(/\\"/g, '"').replace(/\\\\/g, '\\');
}
try {
return config.json ? JSON.parse(s) : s;
} catch(er) {}
}

var config = $.cookie = function (key, value, options) {

// write
if (value !== undefined) {
options = $.extend({}, config.defaults, options);

if (typeof options.expires === 'number') {
var days = options.expires, t = options.expires = new Date();
t.setDate(t.getDate() + days);
}

value = config.json ? JSON.stringify(value) : String(value);

return (document.cookie = [
config.raw ? key : encodeURIComponent(key),
'=',
config.raw ? value : encodeURIComponent(value),
options.expires ? '; expires=' + options.expires.toUTCString() : '', // use expires attribute, max-age is not supported by IE
options.path ? '; path=' + options.path : '',
options.domain ? '; domain=' + options.domain : '',
options.secure ? '; secure' : ''
].join(''));
}

// read
var decode = config.raw ? raw : decoded;
var cookies = document.cookie.split('; ');
var result = key ? undefined : {};
for (var i = 0, l = cookies.length; i < l; i++) {
var parts = cookies[i].split('=');
var name = decode(parts.shift());
var cookie = decode(parts.join('='));

if (key && key === name) {
result = converted(cookie);
break;
}

if (!key) {
result[name] = converted(cookie);
}
}

return result;
};

config.defaults = {};

$.removeCookie = function (key, options) {
if ($.cookie(key) !== undefined) {
// Must not alter options, thus extending a fresh object...
$.cookie(key, '', $.extend({}, options, { expires: -1 }));
return true;
}
return false;
};

}));

/*! ResponsiveSlides.js v1.54
 * http://responsiveslides.com
 * http://viljamis.com
 *
 * Copyright (c) 2011-2012 @viljamis
 * Available under the MIT license
 */

/*jslint browser: true, sloppy: true, vars: true, plusplus: true, indent: 2 */

(function (jQuery, window, i) {
  jQuery.fn.responsiveSlides = function (options) {

    // Default settings
    var settings = jQuery.extend({
      "auto": true,             // Boolean: Animate automatically, true or false
      "speed": 500,             // Integer: Speed of the transition, in milliseconds
      "timeout": 4000,          // Integer: Time between slide transitions, in milliseconds
      "pager": false,           // Boolean: Show pager, true or false
      "nav": false,             // Boolean: Show navigation, true or false
      "random": false,          // Boolean: Randomize the order of the slides, true or false
      "pause": false,           // Boolean: Pause on hover, true or false
      "pauseControls": true,    // Boolean: Pause when hovering controls, true or false
      "prevText": "Previous",   // String: Text for the "previous" button
      "nextText": "Next",       // String: Text for the "next" button
      "maxwidth": "",           // Integer: Max-width of the slideshow, in pixels
      "navContainer": "",       // Selector: Where auto generated controls should be appended to, default is after the <ul>
      "manualControls": "",     // Selector: Declare custom pager navigation
      "namespace": "rslides",   // String: change the default namespace used
      "before": jQuery.noop,         // Function: Before callback
      "after": jQuery.noop           // Function: After callback
    }, options);

    return this.each(function () {

      // Index for namespacing
      i++;

      var jQuerythis = jQuery(this),

        // Local variables
        vendor,
        selectTab,
        startCycle,
        restartCycle,
        rotate,
        jQuerytabs,

        // Helpers
        index = 0,
        jQueryslide = jQuerythis.children(),
        length = jQueryslide.size(),
        fadeTime = parseFloat(settings.speed),
        waitTime = parseFloat(settings.timeout),
        maxw = parseFloat(settings.maxwidth),

        // Namespacing
        namespace = settings.namespace,
        namespaceIdx = namespace + i,

        // Classes
        navClass = namespace + "_nav " + namespaceIdx + "_nav",
        activeClass = namespace + "_here",
        visibleClass = namespaceIdx + "_on",
        slideClassPrefix = namespaceIdx + "_s",

        // Pager
        jQuerypager = jQuery("<ul class='" + namespace + "_tabs " + namespaceIdx + "_tabs' />"),

        // Styles for visible and hidden slides
        visible = {"float": "left", "position": "relative", "opacity": 1, "zIndex": 2},
        hidden = {"float": "none", "position": "absolute", "opacity": 0, "zIndex": 1},

        // Detect transition support
        supportsTransitions = (function () {
          var docBody = document.body || document.documentElement;
          var styles = docBody.style;
          var prop = "transition";
          if (typeof styles[prop] === "string") {
            return true;
          }
          // Tests for vendor specific prop
          vendor = ["Moz", "Webkit", "Khtml", "O", "ms"];
          prop = prop.charAt(0).toUpperCase() + prop.substr(1);
          var i;
          for (i = 0; i < vendor.length; i++) {
            if (typeof styles[vendor[i] + prop] === "string") {
              return true;
            }
          }
          return false;
        })(),

        // Fading animation
        slideTo = function (idx) {
          settings.before(idx);
          // If CSS3 transitions are supported
          if (supportsTransitions) {
            jQueryslide
              .removeClass(visibleClass)
              .css(hidden)
              .eq(idx)
              .addClass(visibleClass)
              .css(visible);
            index = idx;
            setTimeout(function () {
              settings.after(idx);
            }, fadeTime);
          // If not, use jQuery fallback
          } else {
            jQueryslide
              .stop()
              .fadeOut(fadeTime, function () {
                $(this)
                  .removeClass(visibleClass)
                  .css(hidden)
                  .css("opacity", 1);
              })
              .eq(idx)
              .fadeIn(fadeTime, function () {
                jQuery(this)
                  .addClass(visibleClass)
                  .css(visible);
                settings.after(idx);
                index = idx;
              });
          }
        };

      // Random order
      if (settings.random) {
        jQueryslide.sort(function () {
          return (Math.round(Math.random()) - 0.5);
        });
        jQuerythis
          .empty()
          .append(jQueryslide);
      }

      // Add ID's to each slide
      jQueryslide.each(function (i) {
        this.id = slideClassPrefix + i;
      });

      // Add max-width and classes
      jQuerythis.addClass(namespace + " " + namespaceIdx);
      if (options && options.maxwidth) {
        jQuerythis.css("max-width", maxw);
      }

      // Hide all slides, then show first one
      jQueryslide
        .hide()
        .css(hidden)
        .eq(0)
        .addClass(visibleClass)
        .css(visible)
        .show();

      // CSS transitions
      if (supportsTransitions) {
        jQueryslide
          .show()
          .css({
            // -ms prefix isn't needed as IE10 uses prefix free version
            "-webkit-transition": "opacity " + fadeTime + "ms ease-in-out",
            "-moz-transition": "opacity " + fadeTime + "ms ease-in-out",
            "-o-transition": "opacity " + fadeTime + "ms ease-in-out",
            "transition": "opacity " + fadeTime + "ms ease-in-out"
          });
      }

      // Only run if there's more than one slide
      if (jQueryslide.size() > 1) {

        // Make sure the timeout is at least 100ms longer than the fade
        if (waitTime < fadeTime + 100) {
          return;
        }

        // Pager
        if (settings.pager && !settings.manualControls) {
          var tabMarkup = [];
          jQueryslide.each(function (i) {
            var n = i + 1;
            tabMarkup +=
              "<li>" +
              "<a href='#' class='" + slideClassPrefix + n + "'>" + n + "</a>" +
              "</li>";
          });
          jQuerypager.append(tabMarkup);

          // Inject pager
          if (options.navContainer) {
            jQuery(settings.navContainer).append(jQuerypager);
          } else {
            jQuerythis.after(jQuerypager);
          }
        }

        // Manual pager controls
        if (settings.manualControls) {
          jQuerypager = jQuery(settings.manualControls);
          jQuerypager.addClass(namespace + "_tabs " + namespaceIdx + "_tabs");
        }

        // Add pager slide class prefixes
        if (settings.pager || settings.manualControls) {
          jQuerypager.find('li').each(function (i) {
            jQuery(this).addClass(slideClassPrefix + (i + 1));
          });
        }

        // If we have a pager, we need to set up the selectTab function
        if (settings.pager || settings.manualControls) {
          jQuerytabs = jQuerypager.find('a');

          // Select pager item
          selectTab = function (idx) {
            jQuerytabs
              .closest("li")
              .removeClass(activeClass)
              .eq(idx)
              .addClass(activeClass);
          };
        }

        // Auto cycle
        if (settings.auto) {

          startCycle = function () {
            rotate = setInterval(function () {

              // Clear the event queue
              jQueryslide.stop(true, true);

              var idx = index + 1 < length ? index + 1 : 0;

              // Remove active state and set new if pager is set
              if (settings.pager || settings.manualControls) {
                selectTab(idx);
              }

              slideTo(idx);
            }, waitTime);
          };

          // Init cycle
          startCycle();
        }

        // Restarting cycle
        restartCycle = function () {
          if (settings.auto) {
            // Stop
            clearInterval(rotate);
            // Restart
            startCycle();
          }
        };

        // Pause on hover
        if (settings.pause) {
          jQuerythis.hover(function () {
            clearInterval(rotate);
          }, function () {
            restartCycle();
          });
        }

        // Pager click event handler
        if (settings.pager || settings.manualControls) {
          jQuerytabs.bind("click", function (e) {
            e.preventDefault();

            if (!settings.pauseControls) {
              restartCycle();
            }

            // Get index of clicked tab
            var idx = jQuerytabs.index(this);

            // Break if element is already active or currently animated
            if (index === idx || jQuery("." + visibleClass).queue('fx').length) {
              return;
            }

            // Remove active state from old tab and set new one
            selectTab(idx);

            // Do the animation
            slideTo(idx);
          })
            .eq(0)
            .closest("li")
            .addClass(activeClass);

          // Pause when hovering pager
          if (settings.pauseControls) {
            jQuerytabs.hover(function () {
              clearInterval(rotate);
            }, function () {
              restartCycle();
            });
          }
        }

        // Navigation
        if (settings.nav) {
          var navMarkup =
            "<a href='#' class='" + navClass + " prev'>" + settings.prevText + "</a>" +
            "<a href='#' class='" + navClass + " next'>" + settings.nextText + "</a>";

          // Inject navigation
          if (options.navContainer) {
            jQuery(settings.navContainer).append(navMarkup);
          } else {
            jQuerythis.after(navMarkup);
          }

          var jQuerytrigger = jQuery("." + namespaceIdx + "_nav"),
            jQueryprev = jQuerytrigger.filter(".prev");

          // Click event handler
          jQuerytrigger.bind("click", function (e) {
            e.preventDefault();

            var jQueryvisibleClass = jQuery("." + visibleClass);

            // Prevent clicking if currently animated
            if (jQueryvisibleClass.queue('fx').length) {
              return;
            }

            //  Adds active class during slide animation
            //  $(this)
            //    .addClass(namespace + "_active")
            //    .delay(fadeTime)
            //    .queue(function (next) {
            //      $(this).removeClass(namespace + "_active");
            //      next();
            //  });

            // Determine where to slide
            var idx = jQueryslide.index(jQueryvisibleClass),
              prevIdx = idx - 1,
              nextIdx = idx + 1 < length ? index + 1 : 0;

            // Go to slide
            slideTo(jQuery(this)[0] === jQueryprev[0] ? prevIdx : nextIdx);
            if (settings.pager || settings.manualControls) {
              selectTab(jQuery(this)[0] === jQueryprev[0] ? prevIdx : nextIdx);
            }

            if (!settings.pauseControls) {
              restartCycle();
            }
          });

          // Pause when hovering navigation
          if (settings.pauseControls) {
            jQuerytrigger.hover(function () {
              clearInterval(rotate);
            }, function () {
              restartCycle();
            });
          }
        }

      }

      // Max-width fallback
      if (typeof document.body.style.maxWidth === "undefined" && options.maxwidth) {
        var widthSupport = function () {
          jQuerythis.css("width", "100%");
          if (jQuerythis.width() > maxw) {
            jQuerythis.css("width", maxw);
          }
        };

        // Init fallback
        widthSupport();
        jQuery(window).bind("resize", function () {
          widthSupport();
        });
      }

    });

  };
})(jQuery, this, 0);

/*
 * 	Easy Slider 1.7 - jQuery plugin
 *	written by Alen Grakalic	
 *	http://cssglobe.com/post/4004/easy-slider-15-the-easiest-jquery-plugin-for-sliding
 *
 *	Copyright (c) 2009 Alen Grakalic (http://cssglobe.com)
 *	Dual licensed under the MIT (MIT-LICENSE.txt)
 *	and GPL (GPL-LICENSE.txt) licenses.
 *
 *	Built for jQuery library
 *	http://jquery.com
 *
 */
 
/*
 *	markup example for $("#slider").easySlider();
 *	
 * 	<div id="slider">
 *		<ul>
 *			<li><img src="images/01.jpg" alt="" /></li>
 *			<li><img src="images/02.jpg" alt="" /></li>
 *			<li><img src="images/03.jpg" alt="" /></li>
 *			<li><img src="images/04.jpg" alt="" /></li>
 *			<li><img src="images/05.jpg" alt="" /></li>
 *		</ul>
 *	</div>
 *
 */

(function($) {

	$.fn.easySlider = function(options){
	  
		// default configuration properties
		var defaults = {			
			prevId: 		'prevBtn',
			prevText: 		'Previous',
			nextId: 		'nextBtn',	
			nextText: 		'Next',
			controlsShow:	true,
			controlsBefore:	'',
			controlsAfter:	'',	
			controlsFade:	true,
			firstId: 		'firstBtn',
			firstText: 		'First',
			firstShow:		false,
			lastId: 		'lastBtn',	
			lastText: 		'Last',
			lastShow:		false,				
			vertical:		false,
			speed: 			200,
			auto:			false,
			pause:			6000,
			continuous:		false, 
			numeric: 		false,
			numericId: 		'controls'
		}; 
		
		var options = $.extend(defaults, options);  
				
		this.each(function() {  
			var obj = $(this); 				
			var s = $("li", obj).length;
			var w = $("li", obj).width(); 
			var h = $("li", obj).height(); 
			var clickable = true;
			obj.width(w); 
			obj.height(h); 
			obj.css("overflow","hidden");
			var ts = s-1;
			var t = 0;
			$("ul", obj).css('width',s*w);			
			
			if(options.continuous){
				$("ul", obj).prepend($("ul li:last-child", obj).clone().css("margin-left","-"+ w +"px"));
				$("ul", obj).append($("ul li:nth-child(2)", obj).clone());
				$("ul", obj).css('width',(s+1)*w);
			};				
			
			if(!options.vertical) $("li", obj).css('float','left');
								
			if(options.controlsShow){
				var html = options.controlsBefore;				
				if(options.numeric){
					html += '<ol id="'+ options.numericId +'"></ol>';
				} else {
					if(options.firstShow) html += '<span id="'+ options.firstId +'"><a href=\"javascript:void(0);\">'+ options.firstText +'</a></span>';
					html += ' <span id="'+ options.prevId +'"><a href=\"javascript:void(0);\">'+ options.prevText +'</a></span>';
					html += ' <span id="'+ options.nextId +'"><a href=\"javascript:void(0);\">'+ options.nextText +'</a></span>';
					if(options.lastShow) html += ' <span id="'+ options.lastId +'"><a href=\"javascript:void(0);\">'+ options.lastText +'</a></span>';				
				};
				
				html += options.controlsAfter;						
				$(obj).after(html);										
			};
			
			if(options.numeric){									
				for(var i=0;i<s;i++){						
					$(document.createElement("li"))
						.attr('id',options.numericId + (i+1))
						.html('<a rel='+ i +' href=\"javascript:void(0);\">'+ (i+1) +'</a>')
						.appendTo($("#"+ options.numericId))
						.click(function(){							
							animate($("a",$(this)).attr('rel'),true);
						}); 												
				};							
			} else {
				$("a","#"+options.nextId).click(function(){		
					animate("next",true);
				});
				$("a","#"+options.prevId).click(function(){		
					animate("prev",true);				
				});	
				$("a","#"+options.firstId).click(function(){		
					animate("first",true);
				});				
				$("a","#"+options.lastId).click(function(){		
					animate("last",true);				
				});				
			};
			
			function setCurrent(i){
				i = parseInt(i)+1;
				$("li", "#" + options.numericId).removeClass("current");
				$("li#" + options.numericId + i).addClass("current");
			};
			
			function adjust(){
				if(t>ts) t=0;		
				if(t<0) t=ts;	
				if(!options.vertical) {
					$("ul",obj).css("margin-left",(t*w*-1));
				} else {
					$("ul",obj).css("margin-left",(t*h*-1));
				}
				clickable = true;
				if(options.numeric) setCurrent(t);
			};
			
			function animate(dir,clicked){
				if (clickable){
					clickable = false;
					var ot = t;				
					switch(dir){
						case "next":
							t = (ot>=ts) ? (options.continuous ? t+1 : ts) : t+1;						
							break; 
						case "prev":
							t = (t<=0) ? (options.continuous ? t-1 : 0) : t-1;
							break; 
						case "first":
							t = 0;
							break; 
						case "last":
							t = ts;
							break; 
						default:
							t = dir;
							break; 
					};	
					var diff = Math.abs(ot-t);
					var speed = diff*options.speed;						
					if(!options.vertical) {
						p = (t*w*-1);
						$("ul",obj).animate(
							{ marginLeft: p }, 
							{ queue:false, duration:speed, complete:adjust }
						);				
					} else {
						p = (t*h*-1);
						$("ul",obj).animate(
							{ marginTop: p }, 
							{ queue:false, duration:speed, complete:adjust }
						);					
					};
					
					if(!options.continuous && options.controlsFade){					
						if(t==ts){
							$("a","#"+options.nextId).hide();
							$("a","#"+options.lastId).hide();
						} else {
							$("a","#"+options.nextId).show();
							$("a","#"+options.lastId).show();					
						};
						if(t==0){
							$("a","#"+options.prevId).hide();
							$("a","#"+options.firstId).hide();
						} else {
							$("a","#"+options.prevId).show();
							$("a","#"+options.firstId).show();
						};					
					};				
					
					if(clicked) clearTimeout(timeout);
					if(options.auto && dir=="next" && !clicked){;
						timeout = setTimeout(function(){
							animate("next",false);
						},diff*options.speed+options.pause);
					};
			
				};
				
			};
			// init
			var timeout;
			if(options.auto){;
				timeout = setTimeout(function(){
					animate("next",false);
				},options.pause);
			};		
			
			if(options.numeric) setCurrent(0);
		
			if(!options.continuous && options.controlsFade){					
				$("a","#"+options.prevId).hide();
				$("a","#"+options.firstId).hide();				
			};				
			
		});
	  
	};

})(jQuery);
