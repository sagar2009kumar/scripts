<html>
<style>

img {
	width: 60px;
    height: 60px;
    line-height: 60px;
    border-radius: 50%;
    overflow: hidden;
}

</style>

<img src = "http://127.0.0.1/magento19/media//Chat/cust_55/req_1/5b65e935df59c.jpg">
<img src = "http://sokolin.ebizontech.biz/skin/frontend/base/default/images/media/sokolin-logo.jpg" class = "img1">


</html>
