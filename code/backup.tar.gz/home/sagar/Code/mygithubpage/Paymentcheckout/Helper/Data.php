<?php

class Mofluid_Paymentcheckout_Helper_Data extends Mage_Core_Helper_Abstract
{

}
