<?php
class Mofluid_Chat_Helper_Data
    extends Mage_Core_Helper_Abstract
{
}
