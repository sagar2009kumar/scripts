# mygithubpage


http://127.0.0.1/magento19/index.php/mofluid119?service=createnewrequest&customerid=55&sender=ram&receiver=admin&chatmessage=c2hlIGlzIGJvcmluZw==

http://127.0.0.1/magento19/index.php/mofluid119/?service=getallmessages&chatid=1

http://127.0.0.1/magento19/index.php/mofluid119?service=update&chatid=30&sender=ram&receiver=admin&productid=18799&chatmessage=c2hlIGlzIGJvcmluZw==


http://127.0.0.1/magento19/index.php/mofluid119?service=update&chatid=30&sender=ram&receiver=admin&productid=18799&chatmessage=SGVsbG8gaG93IGFyZSB5b3UgPz8=

// message tak

//customer 

logoToDisplay = '<div class = "cust-logo-box"><img src ='+logoCustPath+' alt = "Image" class = "custlogo"></div><div class = "chat-box"><div class = "cust-chat-box"><div class = "message">'+message+'</div></div></div><div class = "admin-logo-box"><img src ='+logoAdminPath+' alt = "Image" class = "adminlogo"></div><div class = "single-message-time">'+time+'</div>';

// admin

logoToDisplay = '<div class = "cust-logo-box"><img src ='+logoCustPath+' alt = "Image" class = "custlogo"></div><div class = "chat-box"><div class = "admin-chat-box"><div class = "message">'+message+'</div></div></div><div class = "admin-logo-box"><img src ='+logoAdminPath+' alt = "Image" class = "adminlogo"></div><div class = "single-message-time">'+time+'</div>';


// Image 

logoToDisplay = '<div class = "cust-logo-box"><img src ='+logoCustPath+' alt = "Image" class = "custlogo"></div><div class = "chat-box"><div class = "admin-chat-box"><div class = "imagebox"><img src='+logoCustPath+' class = "image"></div></div></div><div class = "admin-logo-box"><img src ='+logoAdminPath+' alt = "Image" class = "adminlogo"></div><div class = "single-message-time">'+time+'</div>';

// Image+message

logoToDisplay = '<div class = "cust-logo-box"><img src ='+logoCustPath+' alt = "Image" class = "custlogo"></div><div class = "chat-box"><div class = "admin-chat-box"><div class = "imagebox"><div ><img src='+logoCustPath+' class = "image"></div><div class = "text-message">'+message+'</div></div></div></div><div class = "admin-logo-box"><img src ='+logoAdminPath+' alt = "Image" class = "adminlogo"></div><div class = "single-message-time">'+time+'</div>';
