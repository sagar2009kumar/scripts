<?php
/**
 * Created by PhpStorm.
 * User: dhiraj.gangoosirdar
 * Date: 3/18/2015
 * Time: 8:22 AM
 */

namespace com\checkout\ApiServices\Tokens;


class PaymentTokenMapper
{


}