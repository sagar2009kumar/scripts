<?php
/**
 * User: Santiago del Puerto
 * Date: 13/04/2018
 */

namespace com\checkout\ApiServices\Payouts\RequestModels;


class PayoutCreate extends BasePayout
{
}