<?php

/**
 * class that contain all constant variable that should be use in the utility class
 * Class CheckoutApi_Utility_Constant
 */
final class CheckoutApi_Utility_Constant 
{




	
}

