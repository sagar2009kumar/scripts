<?php

class Mofluid_Chatsystem_Model_Mysql4_Chatsystem extends Mage_Core_Model_Mysql4_Abstract
{
    public function _construct() {    
        // Note that the web_id refers to the key field in your database table.
        parent::_construct();
        $this->_init('mofluid_chatsystem/message_admin','customer_id');
        $this->_init('mofluid_chatsystem/message_json','customer_id');
        $this->_init('mofluid_chatsystem/message_text','customer_id');
    }
}

?>
