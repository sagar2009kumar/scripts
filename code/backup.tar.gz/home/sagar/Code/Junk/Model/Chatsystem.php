<?php

class Mofluid_Chatsystem_Model_Chatsystem extends Mage_Core_Model_Abstract
{
    public function _construct()
    {
        parent::_construct();
        $this->_init('mofluid_chatsystem/message_admin');
        $this->_init('mofluid_chatsystem/message_json');
        $this->_init('mofluid_chatsystem/message_text');
    }
}
