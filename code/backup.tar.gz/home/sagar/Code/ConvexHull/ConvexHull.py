
f = open('a.txt', 'r');

f.readline()
N = int(f.readline().replace("\n", ""))

l = f.readline().replace("\n", "").split(" ");


x = [];
y = [];

cnt = 0;

for i in range(0, N) :

    x.append(int(l[cnt]));
    cnt = cnt + 1;
    y.append(int(l[cnt]));
    cnt = cnt +1;

import numpy as np;
import matplotlib.pyplot as plt;

plt.scatter(x, y);
plt.show();
