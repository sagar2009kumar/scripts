#include<bits/stdc++.h>

using namespace std;

typedef pair<int, int> P;
typedef struct Point { int x; int y; Point(int a, int b) { x = a; y = b; } } Point;
typedef pair<Point, Point> Tangent;

/**** EVERYTHING IS IN CLOCKWISE DIRECTION PLEASE DON'T FORGET THIS ****/

/**** define the macros for the modulo operator ****/
#define modulo(x, N)((x%N+N)%N)

vector<Point> points;

/**** check the orientation of the point p3 w.r.t the line segment joining point p1 and p2 ****/

int checkOrientation(Point &p1, Point &p2, Point &p3) {

    /**** cross product of two vectors ****/
    int result = (p2.x - p1.x)*(p3.y-p2.y) - (p2.y-p1.y)*(p3.x-p2.x);

    if(result == 0) {
        /**** if the result is zero then the points are collinear ****/
        result = 0;
    }else if(result > 0 ) {
        /**** if the result is greater than zero then the point p3 is anticlockwise w.r.t line segment joining p1 and p2 ****/
        /**** i.e the line segment make the left turn ****/
        result = 1;
    }else {
        /**** if the result is less than zero then the point p3 is clockwise w.r.t to line segment joining p1 and p2 ****/
        /**** i.e the line segment make the right turn ****/
        result = -1;
    }

    return result;
}

/**** Logic for sorting the points by the x co-ordinate ****/

int sortByXCoord(Point &p1, Point &p2) {

    return p1.x != p2.x ? p1.x < p2.x : p1.y < p2.y;
}

/**** Function to sort the vector of the points according to the x co-ordinate ****/

void sortPoints(vector<Point> &points) {

    sort(points.begin(), points.end(), sortByXCoord);
}

/**** Function to print the points  ****/

void printPoints(vector<Point> &points) {

    for(int i = 0; i < points.size()-1; i++) {
        printf("%d %d, ",points[i].x, points[i].y);
    }
    printf("%d %d",points[points.size()-1].x, points[points.size()-1].y);
    printf("\n");
}

/**** Compute the upper tangent to the convex hull ****/
/**** returns the index of the upper tangent to the left hull and the right hull ****/

P computeUT(vector<Point> &LH, vector<Point> &RH, int rindex, int lindex) {

    int l = rindex, r = lindex, p = LH.size(), q = RH.size();
    
    while(true) {

        if(checkOrientation(LH[l], RH[r], RH[modulo(r+1, q)]) == 1) {
            /**** i.e the 3rd point is making the left turn w.r.t segment ****/
            r = modulo(r+1, q); continue;
        }

        if(checkOrientation(RH[r], LH[l], LH[modulo(l-1, p)]) == -1) {
            /**** i.e the 3rd point is making the right turn w.r.t segment ****/
            l = modulo(l-1, p); continue;
        }

        break;

    }
    
    return make_pair(l, r);
}

/**** Compute the lower tangent to the convex hull ****/
/**** returns the index of the lower tangent to the left hull and the right hull ****/

P computeLT(vector<Point> &LH, vector<Point> &RH, int rindex, int lindex) {

    int l = rindex, r = lindex, p = LH.size(), q = RH.size();

    while(true) {

        if(checkOrientation(LH[l], RH[r], RH[modulo(r-1, q)]) == -1) {
            /**** i.e the third point is making the right turn ****/
            r = modulo(r-1, q); continue;
        }

        if(checkOrientation(RH[r], LH[l], LH[modulo(l+1, p)]) == 1) {
            /**** i.e the third point is making the left turn ****/
            l = modulo(l+1, p); continue;
        }

        break;
    }

    return make_pair(l, r);
}

/**** merge the two convex hull left hull and the right hull ****/

vector<Point> mergeHull(vector<Point> &LH, vector<Point> &RH) {

    /**** Getting the index of the rightmost point of the left hull ****/
    int rindex = 0;
    for(int i = 0; i < LH.size(); i++) {
        if(LH[rindex].x < LH[i].x) {
            rindex = i;
        }
    }

    /**** Getting the index of the leftmost point of the right hull ****/
    int lindex = 0;
    for(int i = 0; i < RH.size(); i++) {
        if(RH[lindex].x > RH[i].x) {
            lindex = i;
        }
    }

    /**** Getting the index of the upper tangent ****/
    P p1 = computeUT(LH, RH, rindex, lindex);

    /**** Getting the index of the lower tangent ****/
    P p2 = computeLT(LH, RH, rindex, lindex); 

    vector<Point> CH;

    /**** generating the new convex hull ****/

    int p = LH.size(), q = RH.size(), itr = 0;

    /**** pushing the right hull to the convex hull ****/
    for(itr = p1.second; itr != p2.second; itr=modulo(itr+1,q)) CH.push_back(RH[itr]); 
    CH.push_back(RH[itr]);

    /**** pushing the left hull to the conex hull ****/
    for(itr = p2.first; itr != p1.first; itr=modulo(itr+1, p)) CH.push_back(LH[itr]);
    CH.push_back(LH[itr]);

    return CH;
}

/**** function to build the brute convex hull from the points less than or equal to six ****/

vector<Point> bruteHull(vector<Point> &point) {

    int i = 0, j = 0, prevortn = -2, curortn = -2;

    vector<Points> BH;

    for(int i = 0; i < point.size(); i++) {
        for(int j = i+1; j < point.size(); j++) {
            for(int k = 0; k < point.size(); k++) {
                if(k == 0 || k == j) continue;
                if(curortn == -2) {
                    curortn = orientation(point[i], point[j], point[k]);
                    prevortn = curortn;
                }else {
                    curortn = orientation(point[i], point[j], point[k]);
                    if(prevortn != curortn) {
                        break;
                    }else {
                        if(k == point.size()-1) {
                            BH.push_back(point[i]);
                            BH.push_back(point[j]);
                        }else {
                            continue;
                        }
                    }
                }
            }
        }
    }

    return BH;
}

vector<Point> divide(vector<Point> &point) {

    if(point.size() <= 3) {
        return point;
    }
    
    vector<Point> LH, RH;
    
    for(int i = 0; i < point.size()/2; i++) LH.push_back(point[i]);
    for(int i = point.size()/2; i < point.size(); i++) RH.push_back(point[i]);

    LH = divide(LH);
    RH = divide(RH);
    
    vector<Point> MH = mergeHull(LH, RH);
    return MH;
}

vector<Point> convexHull(vector<Point> &point) {

    return divide(point);
}

int main() {

    freopen("a.txt", "r", stdin);

    int testCase = 0;
    
    scanf("%d",&testCase);
    
    while(testCase-- > 0) { 
        
        points.clear();
        int N = 0;
        
        scanf("%d", &N);
        
        int x, y;
    
        for(int i = 0; i < N; i++) {
    
            scanf("%d %d",&x, &y);
            points.push_back(Point(x,y));
        }
        
        if(N < 3) {
            printf("-1\n");
            continue;
        }
    
        sortPoints(points);
        
        vector<Point> CH = convexHull(points);
        
        sortPoints(CH);
        printPoints(CH);
    }

    return 0;
}

// admin password :: 0974026bece5fb6faa6c04e8f4e48778:hpYvd4rIprMtGsnXZ9qOXFNXE7ZezBes
