<?php
class House_Room_IndexController extends Mage_Core_Controller_Front_Action {
	
	public function IndexAction() {

		echo "hello World";

	}
}
?>
